-- Zhiry Bazaar: Supabase starter schema
-- Run this in Supabase SQL Editor only after creating a new project.
-- Each authenticated user can access only their own sales rows.

create extension if not exists pgcrypto;

create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  sale_date date not null,
  product_name text not null check (char_length(product_name) between 1 and 120),
  quantity integer not null check (quantity > 0),
  unit_price_iqd numeric(14,2) not null check (unit_price_iqd >= 0),
  unit_cost_iqd numeric(14,2) not null check (unit_cost_iqd >= 0),
  delivery_cost_iqd numeric(14,2) not null default 0 check (delivery_cost_iqd >= 0),
  ad_cost_iqd numeric(14,2) not null default 0 check (ad_cost_iqd >= 0),
  returns_cost_iqd numeric(14,2) not null default 0 check (returns_cost_iqd >= 0),
  other_cost_iqd numeric(14,2) not null default 0 check (other_cost_iqd >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists sales_user_date_idx
  on public.sales (user_id, sale_date desc);

alter table public.sales enable row level security;

drop policy if exists "Users can read their own sales" on public.sales;
create policy "Users can read their own sales"
  on public.sales for select
  to authenticated
  using (auth.uid() = user_id);

drop policy if exists "Users can insert their own sales" on public.sales;
create policy "Users can insert their own sales"
  on public.sales for insert
  to authenticated
  with check (auth.uid() = user_id);

drop policy if exists "Users can update their own sales" on public.sales;
create policy "Users can update their own sales"
  on public.sales for update
  to authenticated
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Users can delete their own sales" on public.sales;
create policy "Users can delete their own sales"
  on public.sales for delete
  to authenticated
  using (auth.uid() = user_id);

-- No public/anonymous access is granted. Do not expose a service_role key in the browser.
